#!/usr/bin/env python3
"""
plc_servidor.py (v5 - sensores, alarmas y temporizadores)
-----------------------------------------------------------
Simula el controlador (equivalente a un SNAP PAC) de la planta completa
de referencia. Habla Modbus TCP real, sin librerias externas.

Comportamiento fisico simulado:
  - Motores con retardo de arranque (contactor + termico) y valvulas mas
    rapidas. El indicador "corriendo" es una confirmacion distinta del comando.
  - Roscos, elevadores, transportadores y mezcladora tienen ademas un
    SENSOR DE GIRO. Si el motor corre pero el sensor no confirma giro
    (atasco) durante 3 s, salta una alarma y el equipo se dispara.
  - El material de un silo solo llega a la bascula si trabajan a la vez el
    rosco del silo y el elevador (o la valvula) de su sector.
  - Los VDF rampean la frecuencia y exponen On/Run/Ref/Trip; un Trip dispara
    la alarma del equipo asociado.
  - El secuenciador de formula dosifica, mezcla y descarga hacia el silo de
    producto terminado, y aborta con estado ALARMA si algun equipo falla o
    un silo se vacia.
  - Temporizadores: tiempo de vaciado y Kg entregados por cada silo, tiempo
    de dosificacion, mezcla (solo cuenta con la mezcladora girando),
    descarga, total y del ultimo batch.

Uso:
    python3 plc_servidor.py [puerto]   (por defecto 5020)
"""

import socket
import struct
import sys
import threading
import time

import mapa_senales as mapa

HOST = "0.0.0.0"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5020

lock = threading.Lock()

coils = [0] * mapa.N_COILS
discretas = [0] * mapa.N_DISCRETAS
holding_regs = [0] * mapa.N_HOLDING_REGS
input_regs = [0] * mapa.N_INPUT_REGS

# Consignas iniciales
for _v in mapa.VDFS:
    holding_regs[mapa.HOLDING_REG_DE_VDF_CONSIGNA[_v["tag"]]] = 500   # 50.0 Hz
holding_regs[mapa.HOLDING_REG_TIEMPO_MEZCLADO] = 20                   # segundos
holding_regs[mapa.HOLDING_REG_TIEMPO_DESCARGA] = 5                    # segundos

# --- estado interno de la simulacion (no expuesto directo por Modbus) ---
tiempo_comandado = [0.0] * mapa.N_DISPOSITIVOS
niveles_silo_kg = {s["nombre"]: float(s["nivel_inicial_kg"]) for s in mapa.SILOS}
peso_bascula_kg = {b["nombre"]: 0.0 for b in mapa.BASCULAS}
niveles_silo_salida_kg = {s["nombre"]: 0.0 for s in mapa.SILOS_SALIDA}
frecuencia_actual_hz = {v["tag"]: 0.0 for v in mapa.VDFS}
vdf_en_falla = {v["tag"]: False for v in mapa.VDFS}

# alarmas (v5)
alarma_dispositivo = {d["tag"]: 0 for d in mapa.DISPOSITIVOS}   # 0 = sin alarma, si no, codigo
tiempo_sin_sensor = {tag: 0 for tag in mapa.SENSORES}
info_alarma = {"codigo": 0, "idx": 0xFFFF}

# temporizadores (v5)
tiempo_silo_s = {s["nombre"]: 0 for s in mapa.SILOS}
kg_silo_batch = {s["nombre"]: 0.0 for s in mapa.SILOS}
timers = {"total": 0, "dosif": 0, "mezcla": 0, "descarga": 0, "ultimo": 0}

# secuenciador de formula
estado_secuencia = 0     # 0 DETENIDO, 1 DOSIFICANDO, 2 MEZCLANDO, 3 DESCARGANDO, 4 ALARMA
batch_actual = 0
ingrediente_idx = -1
peso_acumulado_previo_kg = 0.0
tiempo_mezclado_restante = 0
tiempo_descarga_restante = 0
destino_override = {}    # silo -> bascula, mientras dosifica el secuenciador
objetivo_dosificacion_kg = 0.0   # peso acumulado objetivo del ingrediente en curso

RETARDO_ARRANQUE_MOTOR = 2.0     # s hasta que el contactor confirma marcha
RETARDO_ARRANQUE_VALVULA = 0.5   # s hasta que el limit switch confirma
TASA_DESCARGA_KG_S = 6.0         # velocidad de dosificacion simulada
RAMPA_VDF_HZ_S = 5.0
TOLERANCIA_REF_HZ = 1.0
SENSOR_TIMEOUT_S = 3             # s con motor corriendo y sin giro -> alarma
NOMBRE_BASCULA_FORMULA = "Bascula General (Formula)"


def _idx(tag):
    """Indice de coil/discreta de marcha de un dispositivo."""
    return mapa.COIL_DE[tag]


def _sensor_ok(tag):
    """True si el equipo esta girando de verdad (o, sin sensor, si esta en marcha)."""
    if tag in mapa.DISCRETA_SENSOR_DE:
        return bool(discretas[mapa.DISCRETA_SENSOR_DE[tag]])
    return bool(discretas[_idx(tag)])


def _hay_alarmas():
    return any(alarma_dispositivo.values())


# ---------------------------------------------------------------
# Alarmas
# ---------------------------------------------------------------
def _parar_equipos_de_secuencia():
    tags = set()
    for f in mapa.FORMULAS:
        for ing in f["ingredientes"]:
            tags.add(mapa.silo_por_nombre(ing["silo"])["motor"])
    tags |= set(mapa.SECTOR_ELEVADOR.values()) | set(mapa.SECTOR_VALVULA.values())
    tags |= {"M-441", "M-442", "M-403", "M-439"}
    tags |= {s["valvula"] for s in mapa.SILOS_SALIDA}
    for t in tags:
        coils[_idx(t)] = 0
    destino_override.clear()


def _levantar_alarma(tag, codigo):
    """Latchea una alarma en un dispositivo y aborta la secuencia si estaba corriendo."""
    global estado_secuencia
    if alarma_dispositivo[tag] == 0:
        alarma_dispositivo[tag] = codigo
        info_alarma["codigo"] = codigo
        info_alarma["idx"] = _idx(tag)
        if estado_secuencia in (1, 2, 3):
            _parar_equipos_de_secuencia()
            estado_secuencia = 4


def _procesar_reset_alarmas():
    global estado_secuencia
    if coils[mapa.COIL_RESET_ALARMAS]:
        for tag in alarma_dispositivo:
            alarma_dispositivo[tag] = 0
        for tag in tiempo_sin_sensor:
            tiempo_sin_sensor[tag] = 0
        info_alarma["codigo"] = 0
        info_alarma["idx"] = 0xFFFF
        if estado_secuencia == 4:
            estado_secuencia = 0
        coils[mapa.COIL_RESET_ALARMAS] = 0


def _procesar_fallas_vdf():
    for v in mapa.VDFS:
        tag = v["tag"]
        if coils[mapa.COIL_VDF_FORZAR_FALLA[tag]]:
            vdf_en_falla[tag] = True
            coils[mapa.COIL_VDF_FORZAR_FALLA[tag]] = 0
        if coils[mapa.COIL_VDF_RESET_FALLA[tag]]:
            vdf_en_falla[tag] = False
            coils[mapa.COIL_VDF_RESET_FALLA[tag]] = 0
            if alarma_dispositivo[v["motor"]] == 3:
                alarma_dispositivo[v["motor"]] = 0
        if vdf_en_falla[tag]:
            _levantar_alarma(v["motor"], 3)


def _evaluar_alarmas_sensores():
    """Motor corriendo pero sin giro confirmado durante SENSOR_TIMEOUT_S -> atasco."""
    for tag in mapa.SENSORES:
        if discretas[_idx(tag)] and not discretas[mapa.DISCRETA_SENSOR_DE[tag]]:
            tiempo_sin_sensor[tag] += 1
            if tiempo_sin_sensor[tag] >= SENSOR_TIMEOUT_S:
                _levantar_alarma(tag, 1)
        else:
            tiempo_sin_sensor[tag] = 0


# ---------------------------------------------------------------
# Equipos y flujo de material
# ---------------------------------------------------------------
def _actualizar_confirmacion_dispositivos():
    """Cada motor/valvula tarda en confirmar marcha; los sensores siguen al giro real."""
    for i, disp in enumerate(mapa.DISPOSITIVOS):
        tag = disp["tag"]
        if alarma_dispositivo[tag]:
            coils[i] = 0                      # proteccion: equipo disparado por alarma
        if coils[i]:
            tiempo_comandado[i] += 1.0
            retardo = (RETARDO_ARRANQUE_VALVULA if disp["tipo"] == "valvula"
                       else RETARDO_ARRANQUE_MOTOR)
            discretas[i] = 1 if tiempo_comandado[i] >= retardo else 0
        else:
            tiempo_comandado[i] = 0.0
            discretas[i] = 0
        if tag in mapa.DISCRETA_SENSOR_DE:
            atascado = coils[mapa.COIL_ATASCO_DE[tag]]
            discretas[mapa.DISCRETA_SENSOR_DE[tag]] = 1 if (discretas[i] and not atascado) else 0


def _silo_fluye(silo):
    """Un silo entrega material solo si rosco + elevador/valvula del sector giran."""
    if niveles_silo_kg[silo["nombre"]] <= 0:
        return False
    tag = silo["motor"]
    if not (discretas[_idx(tag)] and _sensor_ok(tag)):
        return False
    sector = silo["sector"]
    elevador = mapa.SECTOR_ELEVADOR.get(sector)
    if elevador and not (discretas[_idx(elevador)] and _sensor_ok(elevador)):
        return False
    valvula = mapa.SECTOR_VALVULA.get(sector)
    if valvula and not discretas[_idx(valvula)]:
        return False
    return True


def _actualizar_flujo_material():
    for silo in mapa.SILOS:
        nombre = silo["nombre"]
        fluye = _silo_fluye(silo)
        discretas[mapa.DISCRETA_FLUJO_SILO_DE[nombre]] = 1 if fluye else 0
        if fluye:
            destino = destino_override.get(nombre, silo["alimenta_a"])
            flujo = min(TASA_DESCARGA_KG_S, niveles_silo_kg[nombre])
            if nombre in destino_override:
                # corte fino: el ultimo tramo no pasa del objetivo del ingrediente
                restante = objetivo_dosificacion_kg - peso_bascula_kg[destino]
                flujo = min(flujo, max(0.0, restante))
            niveles_silo_kg[nombre] -= flujo
            peso_bascula_kg[destino] += flujo
            tiempo_silo_s[nombre] += 1
            kg_silo_batch[nombre] += flujo


def _procesar_tara():
    for bas in mapa.BASCULAS:
        direccion_tara = mapa.COIL_TARA_DE[bas["nombre"]]
        if coils[direccion_tara]:
            peso_bascula_kg[bas["nombre"]] = 0.0
            coils[direccion_tara] = 0


def _actualizar_vdfs():
    """Rampa de frecuencia real y palabra de estado On/Run/Ref/Trip, tipo ABB."""
    for v in mapa.VDFS:
        tag = v["tag"]
        idx_motor = _idx(v["motor"])
        estado_bits = 0
        if vdf_en_falla[tag]:
            frecuencia_actual_hz[tag] = max(0.0, frecuencia_actual_hz[tag] - RAMPA_VDF_HZ_S * 2)
            estado_bits |= mapa.VDF_BIT_TRIP
        else:
            if coils[idx_motor]:
                estado_bits |= mapa.VDF_BIT_ON
            if discretas[idx_motor]:
                estado_bits |= mapa.VDF_BIT_RUN
                consigna = holding_regs[mapa.HOLDING_REG_DE_VDF_CONSIGNA[tag]] / 10.0
                actual = frecuencia_actual_hz[tag]
                if actual < consigna:
                    actual = min(consigna, actual + RAMPA_VDF_HZ_S)
                elif actual > consigna:
                    actual = max(consigna, actual - RAMPA_VDF_HZ_S)
                frecuencia_actual_hz[tag] = actual
                if abs(actual - consigna) < TOLERANCIA_REF_HZ:
                    estado_bits |= mapa.VDF_BIT_REF
            else:
                frecuencia_actual_hz[tag] = max(0.0, frecuencia_actual_hz[tag] - RAMPA_VDF_HZ_S)
        input_regs[mapa.INPUT_REG_DE_VDF_FRECUENCIA[tag]] = int(frecuencia_actual_hz[tag] * 10)
        input_regs[mapa.INPUT_REG_DE_VDF_ESTADO[tag]] = estado_bits


# ---------------------------------------------------------------
# Secuenciador de formula / batch
# ---------------------------------------------------------------
def _reiniciar_temporizadores_batch():
    for k in ("total", "dosif", "mezcla", "descarga"):
        timers[k] = 0
    for nombre in tiempo_silo_s:
        tiempo_silo_s[nombre] = 0
        kg_silo_batch[nombre] = 0.0


def _procesar_secuencia_formula():
    global estado_secuencia, batch_actual, ingrediente_idx
    global peso_acumulado_previo_kg, tiempo_mezclado_restante, tiempo_descarga_restante
    global objetivo_dosificacion_kg

    idx_formula = max(0, min(holding_regs[mapa.HOLDING_REG_FORMULA_SELECCIONADA],
                             len(mapa.FORMULAS) - 1))
    formula = mapa.FORMULAS[idx_formula]

    # --- comandos de inicio / paro (pulsos autoreseteables) ---
    if coils[mapa.COIL_SECUENCIA_INICIAR]:
        if estado_secuencia == 0 and not _hay_alarmas():
            estado_secuencia = 1
            ingrediente_idx = 0
            peso_acumulado_previo_kg = 0.0
            peso_bascula_kg[NOMBRE_BASCULA_FORMULA] = 0.0
            _reiniciar_temporizadores_batch()
        coils[mapa.COIL_SECUENCIA_INICIAR] = 0

    if coils[mapa.COIL_SECUENCIA_DETENER]:
        if estado_secuencia != 0:
            _parar_equipos_de_secuencia()
            estado_secuencia = 0
            ingrediente_idx = -1
        coils[mapa.COIL_SECUENCIA_DETENER] = 0

    # --- temporizadores globales del batch ---
    if estado_secuencia in (1, 2, 3):
        timers["total"] += 1
    if estado_secuencia == 1:
        timers["dosif"] += 1

    # --- maquina de estados ---
    if estado_secuencia == 1:  # DOSIFICANDO
        ingrediente = formula["ingredientes"][ingrediente_idx]
        silo = mapa.silo_por_nombre(ingrediente["silo"])
        sector = silo["sector"]
        idx_motor = _idx(silo["motor"])
        elevador = mapa.SECTOR_ELEVADOR.get(sector)
        valvula = mapa.SECTOR_VALVULA.get(sector)

        # solo trabaja el elevador/valvula del sector que se esta dosificando
        for el in mapa.SECTOR_ELEVADOR.values():
            coils[_idx(el)] = 1 if el == elevador else 0
        for vl in mapa.SECTOR_VALVULA.values():
            coils[_idx(vl)] = 1 if vl == valvula else 0

        objetivo_total = peso_acumulado_previo_kg + ingrediente["objetivo_kg"]
        peso_actual = peso_bascula_kg[NOMBRE_BASCULA_FORMULA]
        destino_override[silo["nombre"]] = NOMBRE_BASCULA_FORMULA
        objetivo_dosificacion_kg = objetivo_total

        if peso_actual >= objetivo_total - 1e-6:
            coils[idx_motor] = 0
            destino_override.pop(silo["nombre"], None)
            peso_acumulado_previo_kg = objetivo_total
            ingrediente_idx += 1
            if ingrediente_idx >= len(formula["ingredientes"]):
                for el in mapa.SECTOR_ELEVADOR.values():
                    coils[_idx(el)] = 0
                for vl in mapa.SECTOR_VALVULA.values():
                    coils[_idx(vl)] = 0
                estado_secuencia = 2
                tiempo_mezclado_restante = max(1, holding_regs[mapa.HOLDING_REG_TIEMPO_MEZCLADO])
                ingrediente_idx = -1
        elif niveles_silo_kg[silo["nombre"]] <= 0:
            _levantar_alarma(silo["motor"], 2)          # silo vacio: aborta el batch
        else:
            listo = ((elevador is None or _sensor_ok(elevador)) and
                     (valvula is None or bool(discretas[_idx(valvula)])))
            coils[idx_motor] = 1 if listo else 0        # el rosco arranca con el elevador ya girando

    elif estado_secuencia == 2:  # MEZCLANDO (el tiempo solo corre con la mezcladora girando)
        coils[_idx("M-441")] = 1
        if _sensor_ok("M-441"):
            tiempo_mezclado_restante -= 1
            timers["mezcla"] += 1
            if tiempo_mezclado_restante <= 0:
                coils[_idx("M-441")] = 0
                estado_secuencia = 3
                tiempo_descarga_restante = max(1, holding_regs[mapa.HOLDING_REG_TIEMPO_DESCARGA])

    elif estado_secuencia == 3:  # DESCARGANDO: el material se mueve de verdad al silo destino
        destino_valvula = mapa.silo_salida_por_nombre(formula["silo_destino"])["valvula"]
        for t in ("M-442", "M-403", "M-439", destino_valvula):
            coils[_idx(t)] = 1
        if _sensor_ok("M-403") and _sensor_ok("M-439"):
            tiempo_descarga_restante -= 1
            timers["descarga"] += 1
            if tiempo_descarga_restante <= 0:
                for t in ("M-442", "M-403", "M-439", destino_valvula):
                    coils[_idx(t)] = 0
                peso_final = peso_bascula_kg[NOMBRE_BASCULA_FORMULA]
                info_destino = mapa.silo_salida_por_nombre(formula["silo_destino"])
                niveles_silo_salida_kg[formula["silo_destino"]] = min(
                    info_destino["capacidad_kg"],
                    niveles_silo_salida_kg[formula["silo_destino"]] + peso_final)
                batch_actual += 1
                timers["ultimo"] = timers["total"]
                peso_bascula_kg[NOMBRE_BASCULA_FORMULA] = 0.0
                estado_secuencia = 0

    # --- estado de la secuencia hacia los input registers ---
    input_regs[mapa.INPUT_REG_ESTADO_SECUENCIA] = estado_secuencia
    input_regs[mapa.INPUT_REG_BATCH_ACTUAL] = batch_actual
    input_regs[mapa.INPUT_REG_FORMULA_ACTUAL] = idx_formula
    input_regs[mapa.INPUT_REG_INGREDIENTE_IDX] = ingrediente_idx if ingrediente_idx >= 0 else 0xFFFF
    if estado_secuencia == 1 and ingrediente_idx >= 0:
        ingrediente = formula["ingredientes"][ingrediente_idx]
        avance = peso_bascula_kg[NOMBRE_BASCULA_FORMULA] - peso_acumulado_previo_kg
        input_regs[mapa.INPUT_REG_OBJETIVO_INGREDIENTE] = int(ingrediente["objetivo_kg"] * 10)
        input_regs[mapa.INPUT_REG_AVANCE_INGREDIENTE] = max(0, int(avance * 10))
    else:
        input_regs[mapa.INPUT_REG_OBJETIVO_INGREDIENTE] = 0
        input_regs[mapa.INPUT_REG_AVANCE_INGREDIENTE] = 0
    input_regs[mapa.INPUT_REG_TIEMPO_MEZCLADO] = max(0, tiempo_mezclado_restante)


# ---------------------------------------------------------------
# Volcado de todo el estado interno a las tablas Modbus
# ---------------------------------------------------------------
def _volcar_registros():
    for silo in mapa.SILOS:
        n = silo["nombre"]
        input_regs[mapa.INPUT_REG_DE_SILO[n]] = min(65535, max(0, int(niveles_silo_kg[n])))
        input_regs[mapa.INPUT_REG_TIEMPO_SILO[n]] = min(65535, tiempo_silo_s[n])
        input_regs[mapa.INPUT_REG_KG_SILO_BATCH[n]] = min(65535, int(kg_silo_batch[n] * 10))
    for bas in mapa.BASCULAS:
        n = bas["nombre"]
        input_regs[mapa.INPUT_REG_DE_BASCULA[n]] = min(65535, max(0, int(peso_bascula_kg[n] * 10)))
    for silo_s in mapa.SILOS_SALIDA:
        n = silo_s["nombre"]
        input_regs[mapa.INPUT_REG_DE_SILO_SALIDA[n]] = min(65535, max(0, int(niveles_silo_salida_kg[n])))

    input_regs[mapa.INPUT_REG_TIEMPO_BATCH_TOTAL] = min(65535, timers["total"])
    input_regs[mapa.INPUT_REG_TIEMPO_DOSIFICACION] = min(65535, timers["dosif"])
    input_regs[mapa.INPUT_REG_TIEMPO_MEZCLA] = min(65535, timers["mezcla"])
    input_regs[mapa.INPUT_REG_TIEMPO_DESCARGA] = min(65535, timers["descarga"])
    input_regs[mapa.INPUT_REG_TIEMPO_ULTIMO_BATCH] = min(65535, timers["ultimo"])

    alarma_sector = {sec: 0 for sec in mapa.SECTORES}
    activas = 0
    for d in mapa.DISPOSITIVOS:
        a = 1 if alarma_dispositivo[d["tag"]] else 0
        discretas[mapa.DISCRETA_ALARMA_DISP_DE[d["tag"]]] = a
        if a:
            activas += 1
            alarma_sector[d["sector"]] = 1
    for sec, valor in alarma_sector.items():
        discretas[mapa.DISCRETA_ALARMA_SECTOR_DE[sec]] = valor
    input_regs[mapa.INPUT_REG_ALARMA_CODIGO] = info_alarma["codigo"]
    input_regs[mapa.INPUT_REG_ALARMA_DISPOSITIVO] = info_alarma["idx"]
    input_regs[mapa.INPUT_REG_ALARMA_CONTADOR] = activas


def un_ciclo():
    """Un ciclo de scan de la planta (1 s). Orden importante: fallas -> secuencia ->
    equipos -> flujo -> deteccion de atascos -> registros."""
    _procesar_reset_alarmas()
    _procesar_fallas_vdf()
    _procesar_secuencia_formula()
    _actualizar_confirmacion_dispositivos()
    _actualizar_flujo_material()
    _evaluar_alarmas_sensores()
    _procesar_tara()
    _actualizar_vdfs()
    _volcar_registros()


def motor_de_planta():
    """Hilo que simula fisicamente la planta, un ciclo por segundo."""
    while True:
        with lock:
            un_ciclo()
        time.sleep(1)


# ---------------------------------------------------------------
# Implementacion minima del protocolo Modbus TCP (MBAP + PDU)
# ---------------------------------------------------------------
def construir_respuesta(transaccion_id, unit_id, pdu):
    longitud = len(pdu) + 1
    mbap = struct.pack(">HHHB", transaccion_id, 0, longitud, unit_id)
    return mbap + pdu


def leer_bits(tabla, direccion, cantidad):
    return [tabla[direccion + i] for i in range(cantidad)]


def empaquetar_bits(bits):
    n_bytes = (len(bits) + 7) // 8
    datos = bytearray(n_bytes)
    for i, b in enumerate(bits):
        if b:
            datos[i // 8] |= (1 << (i % 8))
    return bytes(datos)


def manejar_pdu(pdu):
    fc = pdu[0]
    with lock:
        if fc == 0x01:  # Read Coils
            direccion, cantidad = struct.unpack(">HH", pdu[1:5])
            datos = empaquetar_bits(leer_bits(coils, direccion, cantidad))
            return bytes([fc, len(datos)]) + datos

        elif fc == 0x02:  # Read Discrete Inputs
            direccion, cantidad = struct.unpack(">HH", pdu[1:5])
            datos = empaquetar_bits(leer_bits(discretas, direccion, cantidad))
            return bytes([fc, len(datos)]) + datos

        elif fc == 0x03:  # Read Holding Registers
            direccion, cantidad = struct.unpack(">HH", pdu[1:5])
            valores = holding_regs[direccion:direccion + cantidad]
            datos = struct.pack(f">{cantidad}H", *valores)
            return bytes([fc, len(datos)]) + datos

        elif fc == 0x04:  # Read Input Registers
            direccion, cantidad = struct.unpack(">HH", pdu[1:5])
            valores = input_regs[direccion:direccion + cantidad]
            datos = struct.pack(f">{cantidad}H", *valores)
            return bytes([fc, len(datos)]) + datos

        elif fc == 0x05:  # Write Single Coil
            direccion, valor = struct.unpack(">HH", pdu[1:5])
            # Interlock Auto/Manual: mientras la secuencia de formula esta
            # activa, el HMI no puede forzar manualmente los motores/valvulas
            # de planta (el PLC los controla el solo). Los coils de tara,
            # de VDF y de la propia secuencia siguen siempre disponibles.
            if estado_secuencia in (1, 2, 3) and direccion < mapa.N_DISPOSITIVOS:
                return pdu  # se ignora el intento, pero se responde igual
            coils[direccion] = 1 if valor == 0xFF00 else 0
            return pdu

        elif fc == 0x06:  # Write Single Register
            direccion, valor = struct.unpack(">HH", pdu[1:5])
            if 0 <= direccion < len(holding_regs):
                holding_regs[direccion] = valor
            return pdu

        else:
            return bytes([fc | 0x80, 0x01])  # excepcion: funcion no soportada


def atender_cliente(conn, addr):
    print(f"[PLC] Cliente HMI conectado desde {addr}")
    with conn:
        while True:
            cabecera = conn.recv(7)
            if not cabecera or len(cabecera) < 7:
                break
            transaccion_id, protocolo, longitud, unit_id = struct.unpack(">HHHB", cabecera)
            pdu = conn.recv(longitud - 1)
            respuesta_pdu = manejar_pdu(pdu)
            conn.sendall(construir_respuesta(transaccion_id, unit_id, respuesta_pdu))
    print(f"[PLC] Cliente {addr} desconectado")


def main():
    threading.Thread(target=motor_de_planta, daemon=True).start()

    servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    servidor.bind((HOST, PORT))
    servidor.listen(5)
    print(f"[PLC] Controlador simulado (planta completa + VDF + formula) en {HOST}:{PORT}")
    print(f"[PLC] {mapa.N_DISPOSITIVOS} dispositivos, {len(mapa.SILOS)} silos, "
          f"{len(mapa.BASCULAS)} basculas, {len(mapa.VDFS)} VDF, {len(mapa.FORMULAS)} formula(s), "
          f"{len(mapa.SILOS_SALIDA)} silos de producto terminado")
    print(f"[PLC] Coils: 0-{mapa.N_COILS - 1}  Discretas: 0-{mapa.N_DISCRETAS - 1}  "
          f"Holding Regs: 0-{mapa.N_HOLDING_REGS - 1}  Input Regs: 0-{mapa.N_INPUT_REGS - 1}")

    try:
        while True:
            conn, addr = servidor.accept()
            threading.Thread(target=atender_cliente, args=(conn, addr), daemon=True).start()
    except KeyboardInterrupt:
        print("\n[PLC] Apagando controlador simulado")
        servidor.close()


if __name__ == "__main__":
    main()

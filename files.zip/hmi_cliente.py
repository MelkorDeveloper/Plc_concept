#!/usr/bin/env python3
"""
hmi_cliente.py (v5 - diagrama animado, sensores, alarmas y temporizadores)
----------------------------------------------------------------
Misma logica Modbus que la version anterior (polling en bloque, 
motores/valvulas con confirmacion real, basculas, VDF, secuenciador
de formula), pero con un aspecto visual mas cercano a la pantalla
real de referencia: fondo azul, silos dibujados con su nivel, cajas
blancas de lectura tipo bascula industrial, y el panel de formula en
un tono oscuro como el "Formula/Batchs" del diagrama.

Todo se dibuja con formas vectoriales simples en Canvas y widgets
tk normales -- nada de imagenes ni librerias graficas pesadas, para
que el consumo de RAM siga siendo minimo (pensado para 1GB de RAM).

Requiere: python3-tk
    sudo apt install python3-tk

Uso:
    python3 hmi_cliente.py [ip_plc] [puerto]
"""

import socket
import struct
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk

import mapa_senales as mapa

IP_PLC = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PUERTO_PLC = int(sys.argv[2]) if len(sys.argv) > 2 else 5020

# =================================================================
# Paleta de colores, inspirada en la pantalla PAC Display de referencia
# =================================================================
AZUL_FONDO = "#1c67c7"        # fondo de las pestañas de sector (como la pantalla real)
AZUL_PANEL = "#0b3f7a"        # barra superior y paneles (VDF, etc)
AZUL_OSCURO = "#07203e"       # panel de Formula/Batchs (lado derecho del diagrama)
BLANCO = "#ffffff"
NEGRO = "#000000"
GRIS_SILO = "#cfd8dc"
BORDE_SILO = "#37474f"
MATERIAL_COLOR = "#8d6e63"
VERDE_ACTIVO = "#00e676"
GRIS_INACTIVO = "#78909c"
ROJO_TRIP = "#e53935"
AMARILLO = "#ffd54f"
CIAN_BARRA = "#26c6da"
TEXTO_CLARO = "#e3f2fd"


def caja_titulo(parent, texto, bg_parent):
    """Caja blanca con texto negro, como los rotulos 'SECTOR X' del diagrama real."""
    return tk.Label(parent, text=texto, bg=BLANCO, fg=NEGRO,
                     font=("Sans", 9, "bold"), relief="solid", bd=1, padx=8, pady=3)


class ClienteModbus:
    """Cliente Modbus TCP minimo, con lectura/escritura en bloque."""

    def __init__(self, ip, puerto):
        self.ip = ip
        self.puerto = puerto
        self.sock = None
        self.transaccion_id = 0
        self.lock = threading.Lock()
        self.conectar()

    def conectar(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(3)
        self.sock.connect((self.ip, self.puerto))

    def _transaccion(self, pdu):
        with self.lock:
            self.transaccion_id = (self.transaccion_id + 1) % 0xFFFF
            mbap = struct.pack(">HHHB", self.transaccion_id, 0, len(pdu) + 1, 1)
            self.sock.sendall(mbap + pdu)
            cabecera = self.sock.recv(7)
            if len(cabecera) < 7:
                raise ConnectionError("PLC cerro la conexion")
            _, _, longitud, _ = struct.unpack(">HHHB", cabecera)
            return self.sock.recv(longitud - 1)

    def leer_coils(self, direccion, cantidad):
        resp = self._transaccion(struct.pack(">BHH", 0x01, direccion, cantidad))
        n_bytes = resp[1]
        datos = resp[2:2 + n_bytes]
        return [(datos[i // 8] >> (i % 8)) & 1 for i in range(cantidad)]

    def leer_discretas(self, direccion, cantidad):
        resp = self._transaccion(struct.pack(">BHH", 0x02, direccion, cantidad))
        n_bytes = resp[1]
        datos = resp[2:2 + n_bytes]
        return [(datos[i // 8] >> (i % 8)) & 1 for i in range(cantidad)]

    def _leer_registros(self, funcion, direccion, cantidad):
        """Lee en bloques de hasta 100 registros (el limite de Modbus es 125 por peticion)."""
        valores = []
        while cantidad > 0:
            n = min(cantidad, 100)
            resp = self._transaccion(struct.pack(">BHH", funcion, direccion, n))
            n_bytes = resp[1]
            valores += list(struct.unpack(f">{n_bytes // 2}H", resp[2:2 + n_bytes]))
            direccion += n
            cantidad -= n
        return valores

    def leer_input_regs(self, direccion, cantidad):
        return self._leer_registros(0x04, direccion, cantidad)

    def leer_holding_regs(self, direccion, cantidad):
        return self._leer_registros(0x03, direccion, cantidad)

    def escribir_coil(self, direccion, valor):
        val = 0xFF00 if valor else 0x0000
        self._transaccion(struct.pack(">BHH", 0x05, direccion, val))

    def escribir_registro(self, direccion, valor):
        self._transaccion(struct.pack(">BHH", 0x06, direccion, valor))


class FilaDispositivo:
    """Motor/valvula: icono M/V, confirmacion real, sensor de giro (S), alarma y
    la opcion de simular un atasco para ver como reacciona el PLC."""

    def __init__(self, parent, disp, cliente, bg=AZUL_FONDO):
        self.disp = disp
        self.cliente = cliente
        self.bg = bg
        self.direccion = mapa.COIL_DE[disp["tag"]]
        self.tiene_sensor = disp["tag"] in mapa.DISCRETA_SENSOR_DE

        self.marco = tk.Frame(parent, bg=bg)
        self.marco.pack(fill="x", pady=2, padx=4)

        letra = "M" if disp["tipo"] == "motor" else "V"
        self.canvas_led = tk.Canvas(self.marco, width=24, height=24, bg=bg,
                                     highlightthickness=0)
        self.led = self.canvas_led.create_oval(2, 2, 22, 22, fill=GRIS_INACTIVO,
                                                outline="black", width=1)
        self.canvas_led.create_text(12, 12, text=letra, fill="white",
                                     font=("Sans", 9, "bold"))
        self.canvas_led.pack(side="left", padx=(0, 4))

        # cuadro del sensor de giro (solo roscos, elevadores, transportadores y mezcladora)
        self.canvas_sensor = tk.Canvas(self.marco, width=18, height=24, bg=bg, highlightthickness=0)
        if self.tiene_sensor:
            self.sens = self.canvas_sensor.create_rectangle(2, 6, 16, 18, fill=GRIS_INACTIVO,
                                                            outline="black")
            self.canvas_sensor.create_text(9, 12, text="S", fill="white", font=("Sans", 7, "bold"))
        self.canvas_sensor.pack(side="left", padx=(0, 6))

        etiqueta = f"{disp['tag']}  {disp['nombre']}"
        tk.Label(self.marco, text=etiqueta, width=28, anchor="w",
                 bg=bg, fg=TEXTO_CLARO, font=("Sans", 9)).pack(side="left")

        self.var_cmd = tk.BooleanVar()
        texto_boton = "Abrir" if disp["tipo"] == "valvula" else "Arrancar"
        self.boton = tk.Checkbutton(self.marco, text=texto_boton, variable=self.var_cmd,
                                     command=self._on_toggle, bg=bg, fg="white",
                                     selectcolor=AZUL_PANEL, activebackground=bg,
                                     activeforeground="white", highlightthickness=0)
        self.boton.pack(side="left")

        self.var_atasco = tk.BooleanVar()
        if self.tiene_sensor:
            self.chk_atasco = tk.Checkbutton(self.marco, text="Atasco", variable=self.var_atasco,
                                              command=self._on_atasco, bg=bg, fg=AMBAR,
                                              selectcolor=AZUL_PANEL, activebackground=bg,
                                              activeforeground=AMBAR, highlightthickness=0)
            self.chk_atasco.pack(side="left")

        self.lbl_estado = tk.Label(self.marco, text="detenido", width=14,
                                    bg=bg, fg="#cfe8ff", font=("Sans", 9))
        self.lbl_estado.pack(side="left", padx=6)

    def _on_toggle(self):
        try:
            self.cliente.escribir_coil(self.direccion, self.var_cmd.get())
        except (ConnectionError, OSError):
            pass

    def _on_atasco(self):
        try:
            self.cliente.escribir_coil(mapa.COIL_ATASCO_DE[self.disp["tag"]], self.var_atasco.get())
        except (ConnectionError, OSError):
            pass

    def actualizar(self, comandado, corriendo_real, sensor=None, alarma=False, atasco=None):
        self.var_cmd.set(bool(comandado))
        if atasco is not None:
            self.var_atasco.set(bool(atasco))
        if alarma:
            self.canvas_led.itemconfig(self.led, fill=ROJO_TRIP)
            self.lbl_estado.config(text="ALARMA", fg="#ff8a80")
        elif corriendo_real:
            self.canvas_led.itemconfig(self.led, fill=VERDE_ACTIVO)
            self.lbl_estado.config(text="corriendo" if self.disp["tipo"] == "motor" else "abierta",
                                   fg="#cfe8ff")
        else:
            self.canvas_led.itemconfig(self.led, fill=GRIS_INACTIVO)
            self.lbl_estado.config(text="arrancando" if comandado else "detenido", fg="#cfe8ff")
        if self.tiene_sensor and sensor is not None:
            if sensor:
                color = VERDE_ACTIVO
            elif corriendo_real:
                color = ROJO_TRIP          # corre pero no gira
            else:
                color = GRIS_INACTIVO
            self.canvas_sensor.itemconfig(self.sens, fill=color)


class FilaSilo:
    """Silo dibujado (cuerpo + cono) con su nivel real relleno, como en el diagrama."""

    def __init__(self, parent, silo, capacidad_kg=10000, bg=AZUL_FONDO, direccion=None):
        self.silo = silo
        self.capacidad_kg = capacidad_kg
        self.bg = bg
        # Por defecto usa la tabla de silos de materia prima; los silos de
        # producto terminado pasan su propia direccion (tabla distinta).
        self.direccion = direccion if direccion is not None else mapa.INPUT_REG_DE_SILO[silo["nombre"]]

        marco = tk.Frame(parent, bg=bg)
        marco.pack(side="left", padx=8, pady=6, anchor="n")

        self.canvas = tk.Canvas(marco, width=46, height=62, bg=bg, highlightthickness=0)
        self.canvas.pack()
        # cuerpo del silo (cilindro visto de frente) y cono de descarga
        self.canvas.create_rectangle(8, 6, 38, 40, fill=GRIS_SILO, outline=BORDE_SILO, width=2)
        self.canvas.create_polygon(8, 40, 38, 40, 23, 56, fill=GRIS_SILO, outline=BORDE_SILO, width=2)
        # rectangulo de nivel (se mueve con canvas.coords, no se recrea)
        self.item_nivel = self.canvas.create_rectangle(10, 38, 36, 38, fill=MATERIAL_COLOR, outline="")
        self.canvas.tag_raise(self.item_nivel)

        nombre_corto = silo["nombre"].replace("Silo ", "").replace(" Granos", "").\
            replace(" Harinas", "").replace(" PreMix", "").replace(" Acido Graso", "")
        tk.Label(marco, text=nombre_corto, bg=bg, fg=TEXTO_CLARO,
                 font=("Sans", 8), wraplength=60, justify="center").pack()
        self.lbl_kg = tk.Label(marco, text="-- Kg", bg=bg, fg=AMARILLO, font=("Sans", 8, "bold"))
        self.lbl_kg.pack()

    def actualizar(self, valor_registro):
        kg = valor_registro
        fraccion = max(0.0, min(1.0, kg / self.capacidad_kg))
        y_top = 40 - fraccion * (40 - 8)
        self.canvas.coords(self.item_nivel, 10, y_top, 36, 39)
        self.lbl_kg.config(text=f"{kg} Kg")


class FilaBascula:
    """Bascula: caja blanca de lectura (como los recuadros de Kg del diagrama) + Tara."""

    def __init__(self, parent, bascula, cliente, bg=AZUL_FONDO):
        self.bascula = bascula
        self.cliente = cliente
        self.direccion_peso = mapa.INPUT_REG_DE_BASCULA[bascula["nombre"]]
        self.direccion_tara = mapa.COIL_TARA_DE[bascula["nombre"]]

        marco = tk.Frame(parent, bg=bg)
        marco.pack(fill="x", pady=6, padx=4)
        tk.Label(marco, text=bascula["nombre"], width=20, anchor="w",
                 bg=bg, fg="white", font=("Sans", 10, "bold")).pack(side="left")
        self.lbl_peso = tk.Label(marco, text="-- Kg", width=11, bg="white", fg="black",
                                  font=("Consolas", 13, "bold"), relief="sunken", bd=3)
        self.lbl_peso.pack(side="left", padx=6)
        tk.Button(marco, text="Tara", command=self._tarar).pack(side="left")

    def _tarar(self):
        try:
            self.cliente.escribir_coil(self.direccion_tara, True)
        except (ConnectionError, OSError):
            pass

    def actualizar(self, valor_registro):
        self.lbl_peso.config(text=f"{valor_registro / 10.0:.1f} Kg")


class FilaVDF:
    """Variador de frecuencia (tipo ABB): consigna, frecuencia real, estado On/Run/Ref/Trip."""

    def __init__(self, parent, vdf, cliente, bg=AZUL_PANEL):
        self.vdf = vdf
        self.cliente = cliente
        self.direccion_consigna = mapa.HOLDING_REG_DE_VDF_CONSIGNA[vdf["tag"]]
        self.direccion_frecuencia = mapa.INPUT_REG_DE_VDF_FRECUENCIA[vdf["tag"]]
        self.direccion_estado = mapa.INPUT_REG_DE_VDF_ESTADO[vdf["tag"]]
        self.direccion_forzar_falla = mapa.COIL_VDF_FORZAR_FALLA[vdf["tag"]]
        self.direccion_reset_falla = mapa.COIL_VDF_RESET_FALLA[vdf["tag"]]

        marco = tk.LabelFrame(parent, text=f"{vdf['tag']}  {vdf['nombre']}",
                               bg=bg, fg="white", font=("Sans", 9, "bold"),
                               labelanchor="nw")
        marco.pack(fill="x", padx=4, pady=(10, 4))

        fila1 = tk.Frame(marco, bg=bg)
        fila1.pack(fill="x", padx=6, pady=4)
        tk.Label(fila1, text="Consigna (Hz):", bg=bg, fg="white").pack(side="left")
        self.entrada_consigna = tk.Entry(fila1, width=6)
        self.entrada_consigna.pack(side="left", padx=4)
        tk.Button(fila1, text="Enviar", command=self._enviar_consigna).pack(side="left")
        self.lbl_frecuencia = tk.Label(fila1, text="Real: -- Hz", width=14, bg=bg, fg=AMARILLO,
                                        font=("Consolas", 10, "bold"))
        self.lbl_frecuencia.pack(side="left", padx=(12, 0))

        fila2 = tk.Frame(marco, bg=bg)
        fila2.pack(fill="x", padx=6, pady=(0, 6))
        self.lbl_estados = tk.Label(fila2, text="On: -  Run: -  Ref: -  Trip: -",
                                     bg=bg, fg="white")
        self.lbl_estados.pack(side="left")
        tk.Button(fila2, text="Forzar Falla", command=self._forzar_falla).pack(side="left", padx=(12, 4))
        tk.Button(fila2, text="Reset Falla", command=self._reset_falla).pack(side="left")

    def _enviar_consigna(self):
        try:
            hz = float(self.entrada_consigna.get())
            self.cliente.escribir_registro(self.direccion_consigna, int(hz * 10))
        except (ValueError, ConnectionError, OSError):
            pass

    def _forzar_falla(self):
        try:
            self.cliente.escribir_coil(self.direccion_forzar_falla, True)
        except (ConnectionError, OSError):
            pass

    def _reset_falla(self):
        try:
            self.cliente.escribir_coil(self.direccion_reset_falla, True)
        except (ConnectionError, OSError):
            pass

    def actualizar(self, frecuencia_reg, estado_bits):
        self.lbl_frecuencia.config(text=f"Real: {frecuencia_reg / 10.0:.1f} Hz")
        on = "SI" if estado_bits & mapa.VDF_BIT_ON else "no"
        run = "SI" if estado_bits & mapa.VDF_BIT_RUN else "no"
        ref = "SI" if estado_bits & mapa.VDF_BIT_REF else "no"
        trip = "SI" if estado_bits & mapa.VDF_BIT_TRIP else "no"
        self.lbl_estados.config(
            text=f"On: {on}  Run: {run}  Ref: {ref}  Trip: {trip}",
            fg=ROJO_TRIP if estado_bits & mapa.VDF_BIT_TRIP else "white")


class FilaIngrediente:
    """Fila de la tabla de formula (panel oscuro), estilo 'Formula/Batchs' del diagrama,
    con el silo de origen, los Kg realmente entregados y el tiempo de vaciado."""

    def __init__(self, parent, ingrediente, bg=AZUL_OSCURO):
        self.ingrediente = ingrediente
        marco = tk.Frame(parent, bg=bg)
        marco.pack(fill="x", padx=4, pady=2)
        tk.Label(marco, text=ingrediente["nombre"], width=17, anchor="w",
                 bg=bg, fg=AMARILLO, font=("Sans", 9, "bold")).pack(side="left")
        tk.Label(marco, text=ingrediente["silo"].replace("Silo ", ""), width=15, anchor="w",
                 bg=bg, fg="#90a4ae", font=("Sans", 8)).pack(side="left")
        tk.Label(marco, text=f"{ingrediente['objetivo_kg']:.1f} Kg", width=9, anchor="e",
                 bg=bg, fg="white", font=("Consolas", 9)).pack(side="left")
        self.barra = ttk.Progressbar(marco, length=120, maximum=ingrediente["objetivo_kg"],
                                      style="Formula.Horizontal.TProgressbar")
        self.barra.pack(side="left", padx=6)
        self.lbl_entregado = tk.Label(marco, text="--", width=9, anchor="e",
                                       bg=bg, fg="white", font=("Consolas", 9))
        self.lbl_entregado.pack(side="left")
        self.lbl_tiempo = tk.Label(marco, text="--", width=7, anchor="e",
                                    bg=bg, fg=CIAN_BARRA, font=("Consolas", 9))
        self.lbl_tiempo.pack(side="left", padx=(6, 0))
        self.lbl_estado = tk.Label(marco, text="pendiente", width=13, bg=bg, fg="#90a4ae")
        self.lbl_estado.pack(side="left", padx=(6, 0))

    def actualizar(self, estado_txt, avance_kg=None, entregado_kg=None, tiempo_s=None):
        colores = {"pendiente": "#90a4ae", "dosificando...": CIAN_BARRA,
                   "completado": VERDE_ACTIVO, "ALARMA": ROJO_TRIP}
        self.lbl_estado.config(text=estado_txt, fg=colores.get(estado_txt, "white"))
        if avance_kg is not None:
            self.barra["value"] = min(avance_kg, self.ingrediente["objetivo_kg"])
        elif estado_txt == "completado":
            self.barra["value"] = self.ingrediente["objetivo_kg"]
        elif entregado_kg:
            self.barra["value"] = min(entregado_kg, self.ingrediente["objetivo_kg"])
        else:
            self.barra["value"] = 0
        if entregado_kg is not None:
            self.lbl_entregado.config(text=f"{entregado_kg:.1f} Kg" if entregado_kg else "--")
        if tiempo_s is not None:
            self.lbl_tiempo.config(text=fmt_mmss(tiempo_s) if tiempo_s else "--")


def fmt_mmss(segundos):
    segundos = int(segundos)
    return f"{segundos // 60:02d}:{segundos % 60:02d}"


ROJO_OSCURO = "#7f1d1d"
AMBAR = "#ffb300"


class PestanaDiagramaGeneral(tk.Frame):
    """Esquema de TODA la planta en una sola pantalla, al estilo de la pantalla
    PAC Display: cada silo con su nivel, cada rosco y elevador con motor (M) y
    sensor de giro (S), lineas de flujo animadas, sectores que se ponen en rojo
    cuando fallan, y un panel con formula, temporizadores y alarmas.

    Interaccion: pasar el mouse sobre un equipo muestra su estado; clic
    izquierdo arranca/para (en manual); clic derecho simula un atasco."""

    ANCHO, ALTO = 1000, 684
    BUS_Y = 346

    def __init__(self, parent, cliente):
        super().__init__(parent, bg=AZUL_FONDO)
        self.cliente = cliente
        self._c = [0] * mapa.N_COILS
        self._d = [0] * mapa.N_DISCRETAS
        self._h = [0] * mapa.N_HOLDING_REGS
        self._r = [0] * mapa.N_INPUT_REGS

        self.dev = {}          # tag -> ids de canvas del equipo
        self.silos = {}        # nombre -> ids del silo de materia prima
        self.silos_salida = {} # nombre -> ids del silo de producto terminado
        self.lineas = []       # lineas de flujo / hilos animados
        self.hdr = {}          # sector -> cabecera
        self.historial = []    # ultimas alarmas vistas por el HMI
        self._ultima_alarma = (0, 0xFFFF)
        self._fase = 0
        self._blink = False
        self._ciclo = 0
        self._info_defecto = ("Pase el mouse sobre un equipo para ver su estado.  "
                              "Clic: arrancar/parar (manual)   Clic derecho: simular atasco")

        self._construir()
        self.after(150, self._animar)

    # ------------------------------------------------------------------
    # Primitivas de dibujo
    # ------------------------------------------------------------------
    def _txt(self, x, y, texto, tam=8, color="white", bold=False, anchor="center", tags=()):
        return self.canvas.create_text(x, y, text=texto, fill=color, anchor=anchor, tags=tags,
                                        font=("Sans", tam, "bold" if bold else "normal"))

    def _linea(self, puntos, cond, ancho=3, color_on=VERDE_ACTIVO, color_off=GRIS_INACTIVO,
               dash_on=(8, 5), dash_off=None, tags=()):
        plano = [v for p in puntos for v in p]
        kw = {"dash": dash_off} if dash_off else {}
        lid = self.canvas.create_line(*plano, fill=color_off, width=ancho, tags=tags, **kw)
        self.lineas.append({"id": lid, "cond": cond, "activa": None, "ancho": ancho,
                            "on": color_on, "off": color_off,
                            "dash_on": dash_on, "dash_off": dash_off})
        return lid

    def _cabecera(self, sector, x, y, w, titulo):
        c = self.canvas
        tg = ("sec:" + sector,)
        r = c.create_rectangle(x, y, x + w, y + 18, fill=BLANCO, outline="black", tags=tg)
        t = c.create_text(x + w / 2, y + 9, text=titulo, fill=NEGRO, font=("Sans", 8, "bold"), tags=tg)
        info = self._txt(x + w + 8, y + 9, "", 8, AMARILLO, anchor="w", tags=tg)
        self.hdr[sector] = {"rect": r, "txt": t, "info": info, "titulo": titulo}

    def _silo(self, nombre, etiqueta, x, y, w, h, cap):
        c = self.canvas
        tg = ("silo:" + nombre, "equipo")
        cuerpo = c.create_rectangle(x, y, x + w, y + h, fill=GRIS_SILO, outline=BORDE_SILO,
                                     width=2, tags=tg)
        c.create_polygon(x, y + h, x + w, y + h, x + w / 2, y + h + 10, fill=GRIS_SILO,
                         outline=BORDE_SILO, width=2, tags=tg)
        nivel = c.create_rectangle(x + 2, y + h - 1, x + w - 2, y + h - 1, fill=MATERIAL_COLOR,
                                    outline="", tags=tg)
        kg = self._txt(x + w / 2, y + h / 2, "", 6, "#0d1b2a", True, tags=tg)
        self._txt(x + w / 2, y - 7, etiqueta, 7, TEXTO_CLARO, tags=tg)
        return {"cuerpo": cuerpo, "nivel": nivel, "kg": kg, "x": x, "y": y, "w": w, "h": h,
                "cap": max(1, cap)}

    def _motor(self, tag, cx, cy, letra="M", r=7):
        """Circulo del motor/valvula + (si corresponde) cuadro S del sensor de giro."""
        c = self.canvas
        tg = ("dev:" + tag, "equipo")
        circ = c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=GRIS_INACTIVO,
                              outline="black", tags=tg)
        c.create_text(cx, cy, text=letra, fill="white", font=("Sans", 7, "bold"), tags=tg)
        sens = None
        if tag in mapa.DISCRETA_SENSOR_DE:
            sx = cx + r + 3
            sens = c.create_rectangle(sx, cy - 5, sx + 10, cy + 5, fill=GRIS_INACTIVO,
                                       outline="black", tags=tg)
            c.create_text(sx + 5, cy, text="S", fill="white", font=("Sans", 6, "bold"), tags=tg)
        self.dev.setdefault(tag, {}).update(circ=circ, sens=sens, letra=letra)

    def _rosco(self, tag, x, y, w):
        c = self.canvas
        tg = ("dev:" + tag, "equipo")
        rect = c.create_rectangle(x, y, x + w, y + 9, fill=GRIS_SILO, outline=BORDE_SILO, tags=tg)
        self.dev.setdefault(tag, {})["rect"] = rect
        self._linea([(x + 3, y + 4.5), (x + w - 3, y + 4.5)], lambda t=tag: self._gira(t),
                    ancho=2, color_on="#1b5e20", color_off=BORDE_SILO, dash_on=(4, 3),
                    dash_off=(4, 3), tags=tg)

    def _elevador(self, tag, x, y, h, acc, lado_tag="abajo"):
        c = self.canvas
        tg = ("dev:" + tag, "equipo")
        rect = c.create_rectangle(x, y, x + 16, y + h, fill=GRIS_SILO, outline=BORDE_SILO,
                                   width=2, tags=tg)
        self.dev.setdefault(tag, {})["rect"] = rect
        self._linea([(x + 8, y + h - 4), (x + 8, y + 4)], lambda t=tag: self._gira(t),
                    ancho=3, color_on="#1b5e20", color_off=BORDE_SILO, dash_on=(5, 4),
                    dash_off=(5, 4), tags=tg)
        self._motor(tag, acc[0], acc[1])
        self._txt(acc[0] + 6, acc[1] + 14, tag, 6, TEXTO_CLARO)

    # ------------------------------------------------------------------
    # Condiciones de actividad (se evaluan contra el ultimo estado leido)
    # ------------------------------------------------------------------
    def _on(self, tag):
        return bool(self._d[mapa.COIL_DE[tag]])

    def _gira(self, tag):
        if tag in mapa.DISCRETA_SENSOR_DE:
            return self._on(tag) and bool(self._d[mapa.DISCRETA_SENSOR_DE[tag]])
        return self._on(tag)

    def _fl(self, silo):
        return bool(self._d[mapa.DISCRETA_FLUJO_SILO_DE[silo]])

    def _fl_sector(self, sector):
        return any(self._fl(s["nombre"]) for s in mapa.SILOS if s["sector"] == sector)

    def _fl_cualquiera(self):
        return any(self._fl(s["nombre"]) for s in mapa.SILOS)

    # ------------------------------------------------------------------
    # Construccion del esquema
    # ------------------------------------------------------------------
    def _construir(self):
        W, H = self.ANCHO, self.ALTO
        barra_y = ttk.Scrollbar(self, orient="vertical")
        barra_x = ttk.Scrollbar(self, orient="horizontal")
        self.canvas = tk.Canvas(self, bg=AZUL_FONDO, highlightthickness=0,
                                 scrollregion=(0, 0, W, H),
                                 yscrollcommand=barra_y.set, xscrollcommand=barra_x.set)
        barra_y.config(command=self.canvas.yview)
        barra_x.config(command=self.canvas.xview)
        barra_y.pack(side="right", fill="y")
        barra_x.pack(side="bottom", fill="x")
        self.canvas.pack(side="left", fill="both", expand=True)
        c = self.canvas
        by = self.BUS_Y

        # ---------------- HARINAS ----------------
        self._cabecera("HARINAS", 10, 6, 120, "SECTOR HARINAS")
        xs = self._bloque_silos("HARINAS", 12, 40, 46, 30, 38, 92, 114, 132, 7)
        self._linea([(xs[0], 132), (292, 132)], lambda: self._fl_sector("HARINAS"))
        self._elevador("M-402", 292, 44, 96, (300, 154))
        self._linea([(300, 44), (300, 36), (380, 36), (380, by)], lambda: self._fl_sector("HARINAS"))
        self.txt_vdf402 = self._txt(318, 70, "VDF-402\n-- Hz", 7, AMARILLO, True, anchor="w")

        # ---------------- PREMIX ----------------
        self._cabecera("PREMIX", 10, 178, 110, "SECTOR PRE MIX")
        xs = self._bloque_silos("PREMIX", 12, 214, 38, 24, 32, 258, 280, 296, 6)
        self._linea([(xs[0], 296), (322, 296)], lambda: self._fl_sector("PREMIX"))
        self._elevador("M-401", 322, 212, 92, (330, 320))
        self._linea([(330, 212), (330, 204), (358, 204), (358, by)], lambda: self._fl_sector("PREMIX"))

        # ---------------- ACIDO GRASO ----------------
        self._cabecera("ACIDO_GRASO", 10, 352, 120, "ACIDO GRASO")
        silo30 = mapa.SILOS[-1]
        self.silos[silo30["nombre"]] = self._silo(silo30["nombre"], "30", 14, 386, 30, 34,
                                                  silo30["nivel_inicial_kg"])
        self._rosco(silo30["motor"], 12, 434, 36)
        self._motor(silo30["motor"], 30, 458)
        self._motor("M-437", 80, 438.5, "V", 7)
        self._linea([(48, 438.5), (73, 438.5)], lambda: self._fl("Silo 30 Acido Graso"))
        self._linea([(87, 438.5), (430, 438.5), (430, 398), (450, 398)],
                    lambda: self._fl("Silo 30 Acido Graso"))

        # ---------------- GRANOS ----------------
        self._cabecera("GRANOS", 640, 6, 110, "SECTOR GRANOS")
        xs = self._bloque_silos("GRANOS", 644, 40, 46, 30, 38, 92, 114, 132, 7)
        self._linea([(xs[0], 132), (904, 132)], lambda: self._fl_sector("GRANOS"))
        self._elevador("M-400", 904, 44, 96, (912, 154))
        self._linea([(920, 70), (960, 70), (960, by)], lambda: self._fl_sector("GRANOS"))

        # ---------------- ENTEROS ----------------
        self._cabecera("ENTEROS", 640, 188, 100, "ENTEROS")
        c.create_polygon(642, 210, 666, 210, 654, 226, fill=GRIS_SILO, outline=BORDE_SILO, width=2)
        self._rosco("M-409", 668, 222, 100)
        self._motor("M-409", 786, 226.5)
        self._motor("M-428", 826, 226.5, "V", 7)
        self.txt_vdf409 = self._txt(668, 250, "VDF-409  -- Hz", 7, AMARILLO, True, anchor="w")
        self._linea([(768, 226.5), (779, 226.5)], lambda: self._gira("M-409"))
        self._linea([(833, 226.5), (840, 226.5), (840, by)],
                    lambda: self._gira("M-409") and self._on("M-428"))

        # ---------------- BUS HACIA LA MEZCLADORA ----------------
        self._linea([(358, by), (380, by)], lambda: self._fl_sector("PREMIX"))
        self._linea([(380, by), (520, by)],
                    lambda: self._fl_sector("PREMIX") or self._fl_sector("HARINAS"))
        self._linea([(960, by), (840, by)], lambda: self._fl_sector("GRANOS"))
        self._linea([(840, by), (520, by)],
                    lambda: self._fl_sector("GRANOS") or (self._gira("M-409") and self._on("M-428")))
        self._linea([(520, by), (520, 360)], self._fl_cualquiera)

        # ---------------- MEZCLADORA ----------------
        tgm = ("sec:MEZCLADORA",)
        mez = c.create_rectangle(450, 360, 590, 438, fill=AZUL_PANEL, outline="white", width=2, tags=tgm)
        mtxt = c.create_text(520, 369, text="MEZCLADORA", fill="white", font=("Sans", 8, "bold"), tags=tgm)
        self.hdr["MEZCLADORA"] = {"rect": mez, "txt": mtxt, "info": None, "titulo": "MEZCLADORA"}
        c.create_rectangle(468, 377, 572, 395, fill=BLANCO, outline="black")
        self.txt_bascula = self._txt(520, 386, "0.0 Kg", 10, NEGRO, True)
        self._txt(520, 402, "BASCULA GENERAL", 6, TEXTO_CLARO)
        self._motor("M-441", 470, 423)
        self.txt_mezcla = self._txt(496, 423, "Mezc 00/00s", 7, AMARILLO, True, anchor="w")
        self._linea([(520, 438), (520, 441)], lambda: self._on("M-442"))
        self._motor("M-442", 520, 448, "V", 7)
        self._linea([(520, 455), (520, 466)], lambda: self._on("M-442"))

        # ---------------- SALIDA ----------------
        self._cabecera("SALIDA", 544, 498, 62, "SALIDA")
        self.canvas.delete(self.hdr["SALIDA"]["info"])
        self.hdr["SALIDA"]["info"] = None
        self._elevador("M-403", 512, 466, 60, (486, 498))
        self._linea([(520, 526), (520, 535.5), (540, 535.5)], lambda: self._gira("M-403"))
        self._rosco("M-439", 540, 531, 200)
        self._motor("M-439", 756, 535.5)
        self._linea([(740, 535.5), (749, 535.5)], lambda: self._gira("M-439"))
        self._linea([(783, 535.5), (800, 535.5), (800, 560)], lambda: self._gira("M-439"))
        dist_x = [232 + 66 * i + 17 for i in range(len(mapa.SILOS_SALIDA))]
        self._linea([(800, 560), (dist_x[0], 560)], lambda: self._gira("M-439"))
        for i, ss in enumerate(mapa.SILOS_SALIDA):
            x = 232 + 66 * i
            cx = x + 17
            self.silos_salida[ss["nombre"]] = self._silo(
                ss["nombre"], "", x, 582, 34, 34, ss["capacidad_kg"])
            self._motor(ss["valvula"], cx, 572, "V", 6)
            self._linea([(cx, 560), (cx, 566)], lambda t=ss["valvula"]: self._on(t))

        # ---------------- PANEL FORMULA / TIEMPOS / ALARMAS ----------------
        c.create_rectangle(610, 354, 995, 526, fill=AZUL_OSCURO, outline=BORDE_SILO, width=2)
        self._txt(620, 366, "FORMULA / BATCH", 9, "white", True, anchor="w")
        self.t_formula = self._txt(620, 383, "Formula: --", 8, AMARILLO, anchor="w")
        self.t_estado = self._txt(620, 398, "Estado: DETENIDO", 8, "white", True, anchor="w")
        self.t_batch = self._txt(620, 413, "Batchs: 0", 8, "white", anchor="w")
        self.t_ingr = self._txt(620, 428, "Ingrediente: --", 8, CIAN_BARRA, anchor="w")
        self.t_avance = self._txt(620, 443, "", 8, "white", anchor="w")
        self._txt(620, 460, "TIEMPOS DE PROCESO", 8, "white", True, anchor="w")
        self.t_t1 = self._txt(620, 474, "", 8, "white", anchor="w")
        self.t_t2 = self._txt(620, 488, "", 8, "white", anchor="w")
        self.t_t3 = self._txt(620, 502, "", 8, "white", anchor="w")
        self.t_t4 = self._txt(620, 516, "", 8, "white", anchor="w")
        c.create_line(808, 360, 808, 520, fill=BORDE_SILO)
        self.t_alarma_t = self._txt(818, 366, "ALARMAS", 9, VERDE_ACTIVO, True, anchor="w")
        self.t_al = [self._txt(818, 383 + 14 * i, "", 7, "white", anchor="w") for i in range(4)]

        def boton(texto, y, color, fg, cmd):
            b = tk.Button(self, text=texto, bg=color, fg=fg, font=("Sans", 8, "bold"), command=cmd)
            c.create_window(818, y, window=b, anchor="nw", width=168, height=20)
        boton("Iniciar Batch", 446, VERDE_ACTIVO, "black", lambda: self._pulso(mapa.COIL_SECUENCIA_INICIAR))
        boton("Detener", 470, ROJO_TRIP, "white", lambda: self._pulso(mapa.COIL_SECUENCIA_DETENER))
        boton("Reset Alarmas", 494, AMBAR, "black", lambda: self._pulso(mapa.COIL_RESET_ALARMAS))

        # barra de informacion (hover)
        self.t_info = self._txt(10, 671, self._info_defecto, 8, TEXTO_CLARO, anchor="w")

        c.tag_raise("equipo")
        c.bind("<Motion>", self._on_motion)
        c.bind("<Button-1>", lambda e: self._on_click(e, False))
        c.bind("<Button-3>", lambda e: self._on_click(e, True))

    def _bloque_silos(self, sector, x0, ytop, dx, w, h, y_rosco, y_motor, y_coll, rr):
        """Fila de silos de un sector, cada uno con su rosco, motor y sensor.
        Devuelve la posicion x de la primera derivacion al colector."""
        xs = []
        for i, s in enumerate([s for s in mapa.SILOS if s["sector"] == sector]):
            x = x0 + i * dx
            etiqueta = s["nombre"].split()[1]
            self.silos[s["nombre"]] = self._silo(s["nombre"], etiqueta, x, ytop, w, h,
                                                 s["nivel_inicial_kg"])
            self._rosco(s["motor"], x - 2, y_rosco, w + 4)
            cx = x + w / 2 - 4
            self._motor(s["motor"], cx, y_motor, "M", rr)
            self._linea([(cx, y_motor + rr), (cx, y_coll)],
                        lambda n=s["nombre"]: self._fl(n), ancho=2)
            xs.append(cx)
        return xs

    # ------------------------------------------------------------------
    # Interaccion
    # ------------------------------------------------------------------
    def _pulso(self, direccion):
        try:
            self.cliente.escribir_coil(direccion, True)
        except (ConnectionError, OSError):
            pass

    def _tag_actual(self, prefijo):
        items = self.canvas.find_withtag("current")
        if not items:
            return None
        for t in self.canvas.gettags(items[0]):
            if t.startswith(prefijo):
                return t[len(prefijo):]
        return None

    def _texto_dispositivo(self, tag):
        disp = mapa.dispositivo_por_tag(tag)
        i = mapa.COIL_DE[tag]
        orden = "ON" if self._c[i] else "OFF"
        marcha = "SI" if self._d[i] else "NO"
        txt = f"{tag}  {disp['nombre']}  [{mapa.CLASE_DE_TAG[tag]}]   Orden: {orden}   Marcha: {marcha}"
        if tag in mapa.DISCRETA_SENSOR_DE:
            s = self._d[mapa.DISCRETA_SENSOR_DE[tag]]
            if s:
                txt += "   Sensor de giro: OK"
            elif self._d[i]:
                txt += "   Sensor de giro: SIN GIRO (atasco?)"
            else:
                txt += "   Sensor de giro: --"
            if self._c[mapa.COIL_ATASCO_DE[tag]]:
                txt += "   [atasco simulado]"
        if self._d[mapa.DISCRETA_ALARMA_DISP_DE[tag]]:
            causa = ""
            if self._r[mapa.INPUT_REG_ALARMA_DISPOSITIVO] == i:
                causa = ": " + mapa.CODIGOS_ALARMA.get(self._r[mapa.INPUT_REG_ALARMA_CODIGO], "")
            txt += f"   *** ALARMA{causa} ***"
        return txt

    def _texto_silo(self, nombre):
        r = self._r
        if nombre in mapa.INPUT_REG_DE_SILO:
            s = self.silos[nombre]
            kg = r[mapa.INPUT_REG_DE_SILO[nombre]]
            t = r[mapa.INPUT_REG_TIEMPO_SILO[nombre]]
            kb = r[mapa.INPUT_REG_KG_SILO_BATCH[nombre]] / 10.0
            est = "ENTREGANDO" if self._fl(nombre) else "en espera"
            return (f"{nombre}: {kg} Kg ({100 * kg // s['cap']}%)   Ultimo vaciado: {kb:.1f} Kg en {t} s   {est}")
        kg = r[mapa.INPUT_REG_DE_SILO_SALIDA[nombre]]
        return f"{nombre} (producto terminado): {kg} Kg"

    def _on_motion(self, ev):
        tag = self._tag_actual("dev:")
        if tag:
            self.canvas.itemconfig(self.t_info, text=self._texto_dispositivo(tag))
            return
        silo = self._tag_actual("silo:")
        if silo:
            self.canvas.itemconfig(self.t_info, text=self._texto_silo(silo))
            return
        self.canvas.itemconfig(self.t_info, text=self._info_defecto)

    def _on_click(self, ev, derecho):
        tag = self._tag_actual("dev:")
        if not tag:
            return
        try:
            if derecho:
                if tag in mapa.COIL_ATASCO_DE:
                    d = mapa.COIL_ATASCO_DE[tag]
                    self.cliente.escribir_coil(d, not self._c[d])
            else:
                if self._r[mapa.INPUT_REG_ESTADO_SECUENCIA] in (1, 2, 3):
                    self.canvas.itemconfig(self.t_info,
                                           text="Secuencia en curso: el PLC ignora el mando manual (Auto).")
                    return
                i = mapa.COIL_DE[tag]
                self.cliente.escribir_coil(i, not self._c[i])
        except (ConnectionError, OSError):
            pass

    # ------------------------------------------------------------------
    # Actualizacion con los datos leidos del PLC
    # ------------------------------------------------------------------
    def actualizar(self, coils, discretas, holding_regs, input_regs):
        self._c, self._d, self._h, self._r = coils, discretas, holding_regs, input_regs
        self._registrar_alarma()
        self._pintar_equipos()
        self._pintar_silos()
        self._pintar_cabeceras()
        self._pintar_panel()
        self._pintar_lineas()
        self._on_motion(None)

    def _registrar_alarma(self):
        codigo = self._r[mapa.INPUT_REG_ALARMA_CODIGO]
        idx = self._r[mapa.INPUT_REG_ALARMA_DISPOSITIVO]
        clave = (codigo, idx)
        if codigo and clave != self._ultima_alarma and idx < len(mapa.DISPOSITIVOS):
            tag = mapa.DISPOSITIVOS[idx]["tag"]
            self.historial.append((time.strftime("%H:%M:%S"), tag,
                                   mapa.CODIGOS_ALARMA.get(codigo, f"codigo {codigo}")))
            self.historial = self.historial[-20:]
        self._ultima_alarma = clave if codigo else (0, 0xFFFF)

    def _pintar_equipos(self):
        c = self.canvas
        for tag, e in self.dev.items():
            i = mapa.COIL_DE[tag]
            alarma = self._d[mapa.DISCRETA_ALARMA_DISP_DE[tag]]
            if alarma:
                color = ROJO_TRIP if self._blink else ROJO_OSCURO
            elif self._d[i]:
                color = VERDE_ACTIVO
            elif self._c[i]:
                color = AMBAR
            else:
                color = GRIS_INACTIVO
            c.itemconfig(e["circ"], fill=color)
            if e.get("sens") is not None:
                s = self._d[mapa.DISCRETA_SENSOR_DE[tag]]
                if s:
                    cs = VERDE_ACTIVO
                elif self._d[i]:
                    cs = ROJO_TRIP          # corre pero no gira: atasco
                else:
                    cs = GRIS_INACTIVO
                c.itemconfig(e["sens"], fill=cs)
            if e.get("rect") is not None:
                c.itemconfig(e["rect"], fill="#c8e6c9" if self._gira(tag) else GRIS_SILO,
                             outline=ROJO_TRIP if alarma else BORDE_SILO)

    def _pintar_silos(self):
        c = self.canvas
        r = self._r
        stock = {}
        batch = {}
        for s in mapa.SILOS:
            n = s["nombre"]
            ids = self.silos[n]
            kg = r[mapa.INPUT_REG_DE_SILO[n]]
            frac = max(0.0, min(1.0, kg / ids["cap"]))
            y_top = ids["y"] + ids["h"] - 1 - frac * (ids["h"] - 2)
            c.coords(ids["nivel"], ids["x"] + 2, y_top, ids["x"] + ids["w"] - 2, ids["y"] + ids["h"] - 1)
            c.itemconfig(ids["kg"], text=str(kg))
            if kg <= 0:
                borde = ROJO_TRIP
            elif self._fl(n):
                borde = CIAN_BARRA
            elif frac < 0.10:
                borde = AMBAR
            else:
                borde = BORDE_SILO
            c.itemconfig(ids["cuerpo"], outline=borde)
            stock[s["sector"]] = stock.get(s["sector"], 0) + kg
            batch[s["sector"]] = batch.get(s["sector"], 0.0) + r[mapa.INPUT_REG_KG_SILO_BATCH[n]] / 10.0
        self._stock, self._batch_kg = stock, batch

        for ss in mapa.SILOS_SALIDA:
            ids = self.silos_salida[ss["nombre"]]
            kg = r[mapa.INPUT_REG_DE_SILO_SALIDA[ss["nombre"]]]
            frac = max(0.0, min(1.0, kg / ids["cap"]))
            y_top = ids["y"] + ids["h"] - 1 - frac * (ids["h"] - 2)
            c.coords(ids["nivel"], ids["x"] + 2, y_top, ids["x"] + ids["w"] - 2, ids["y"] + ids["h"] - 1)
            c.itemconfig(ids["kg"], text=str(kg) if kg else "")
            self._txt_silo_salida(ids, ss["nombre"], kg)

    def _txt_silo_salida(self, ids, nombre, kg):
        """Texto del nombre y los Kg bajo cada silo de producto terminado."""
        if "pie" not in ids:
            ids["pie"] = self._txt(ids["x"] + ids["w"] / 2, 636, nombre.replace("Silo ", ""),
                                   7, TEXTO_CLARO)
            ids["pie_kg"] = self._txt(ids["x"] + ids["w"] / 2, 648, "", 7, AMARILLO, True)
        self.canvas.itemconfig(ids["pie_kg"], text=f"{kg} Kg")

    def _causa_alarma_sector(self, sector):
        tags = [d["tag"] for d in mapa.DISPOSITIVOS
                if d["sector"] == sector and self._d[mapa.DISCRETA_ALARMA_DISP_DE[d["tag"]]]]
        if not tags:
            return ""
        codigo = self._r[mapa.INPUT_REG_ALARMA_CODIGO]
        idx = self._r[mapa.INPUT_REG_ALARMA_DISPOSITIVO]
        for t in tags:
            if mapa.COIL_DE[t] == idx:
                return f"{t}: {mapa.CODIGOS_ALARMA.get(codigo, '')}"
        return ", ".join(tags)

    def _pintar_cabeceras(self):
        c = self.canvas
        for sector, h in self.hdr.items():
            alarma = self._d[mapa.DISCRETA_ALARMA_SECTOR_DE[sector]]
            color_alarma = ROJO_TRIP if self._blink else ROJO_OSCURO
            if sector == "MEZCLADORA":
                c.itemconfig(h["rect"], fill=color_alarma if alarma else AZUL_PANEL)
                continue
            if alarma:
                c.itemconfig(h["rect"], fill=color_alarma)
                c.itemconfig(h["txt"], fill="white")
                if h["info"] is not None:
                    c.itemconfig(h["info"], text="FALLA  " + self._causa_alarma_sector(sector),
                                 fill="white", font=("Sans", 8, "bold"))
            else:
                c.itemconfig(h["rect"], fill=BLANCO)
                c.itemconfig(h["txt"], fill=NEGRO)
                if h["info"] is not None:
                    if sector in getattr(self, "_stock", {}):
                        texto = (f"Stock {self._stock[sector]} Kg  |  "
                                 f"Ultimo batch {self._batch_kg[sector]:.0f} Kg")
                    else:
                        texto = ""
                    c.itemconfig(h["info"], text=texto, fill=AMARILLO, font=("Sans", 8))

    def _pintar_panel(self):
        c = self.canvas
        r = self._r
        estado = r[mapa.INPUT_REG_ESTADO_SECUENCIA]
        formula = mapa.FORMULAS[min(r[mapa.INPUT_REG_FORMULA_ACTUAL], len(mapa.FORMULAS) - 1)]
        idx = r[mapa.INPUT_REG_INGREDIENTE_IDX]

        c.itemconfig(self.t_formula, text=f"Formula: {formula['id']}  ->  {formula['silo_destino']}")
        color_estado = ROJO_TRIP if estado == 4 else "white"
        c.itemconfig(self.t_estado, text=f"Estado: {mapa.ESTADOS_SECUENCIA[estado]}", fill=color_estado)
        c.itemconfig(self.t_batch, text=f"Batchs: {r[mapa.INPUT_REG_BATCH_ACTUAL]}")
        if idx != 0xFFFF and idx < len(formula["ingredientes"]) and estado in (1, 4):
            ing = formula["ingredientes"][idx]
            pref = "Interrumpido en" if estado == 4 else "Ingrediente"
            c.itemconfig(self.t_ingr, text=f"{pref}: {ing['nombre']}")
            if estado == 1:
                c.itemconfig(self.t_avance, text=f"{r[mapa.INPUT_REG_AVANCE_INGREDIENTE] / 10.0:.1f} / "
                                                 f"{r[mapa.INPUT_REG_OBJETIVO_INGREDIENTE] / 10.0:.1f} Kg")
            else:
                c.itemconfig(self.t_avance, text="")
        else:
            c.itemconfig(self.t_ingr, text="Ingrediente: --")
            c.itemconfig(self.t_avance, text="")

        sp_mez = self._h[mapa.HOLDING_REG_TIEMPO_MEZCLADO]
        sp_des = self._h[mapa.HOLDING_REG_TIEMPO_DESCARGA]
        c.itemconfig(self.t_t1, text=f"Total {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_BATCH_TOTAL])}    "
                                     f"Dosificacion {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_DOSIFICACION])}")
        c.itemconfig(self.t_t2, text=f"Mezcla {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_MEZCLA])} / {fmt_mmss(sp_mez)}")
        c.itemconfig(self.t_t3, text=f"Descarga {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_DESCARGA])} / {fmt_mmss(sp_des)}")
        c.itemconfig(self.t_t4, text=f"Ultimo batch completo: {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_ULTIMO_BATCH])}")

        c.itemconfig(self.txt_bascula,
                     text=f"{r[mapa.INPUT_REG_DE_BASCULA['Bascula General (Formula)']] / 10.0:.1f} Kg")
        c.itemconfig(self.txt_mezcla, text=f"Mezc {r[mapa.INPUT_REG_TIEMPO_MEZCLA]:02d}/{sp_mez:02d}s")

        for tag, item in (("VDF-402", self.txt_vdf402), ("VDF-409", self.txt_vdf409)):
            hz = r[mapa.INPUT_REG_DE_VDF_FRECUENCIA[tag]] / 10.0
            bits = r[mapa.INPUT_REG_DE_VDF_ESTADO[tag]]
            falla = bool(bits & mapa.VDF_BIT_TRIP)
            txt = f"{tag}\n{hz:.1f} Hz" if tag == "VDF-402" else f"{tag}  {hz:.1f} Hz"
            if falla:
                txt += "  TRIP"
            c.itemconfig(item, text=txt, fill=ROJO_TRIP if falla else AMARILLO)

        activas = r[mapa.INPUT_REG_ALARMA_CONTADOR]
        if activas:
            c.itemconfig(self.t_alarma_t, text=f"ALARMAS ACTIVAS: {activas}", fill=ROJO_TRIP)
        else:
            c.itemconfig(self.t_alarma_t, text="ALARMAS: ninguna", fill=VERDE_ACTIVO)
        ultimas = self.historial[-4:][::-1]
        for i, item in enumerate(self.t_al):
            if i < len(ultimas):
                hora, tag, causa = ultimas[i]
                c.itemconfig(item, text=f"{hora} {tag} {causa}", fill="white" if i == 0 else "#90a4ae")
            else:
                c.itemconfig(item, text="")

    def _pintar_lineas(self):
        c = self.canvas
        for l in self.lineas:
            activa = bool(l["cond"]())
            if activa == l["activa"]:
                continue
            l["activa"] = activa
            if activa:
                c.itemconfig(l["id"], fill=l["on"], width=l["ancho"] + (1 if l["ancho"] >= 3 else 0),
                             dash=l["dash_on"])
            else:
                c.itemconfig(l["id"], fill=l["off"], width=l["ancho"],
                             dash=l["dash_off"] if l["dash_off"] else "")

    def _animar(self):
        """Marcha de hormigas sobre las lineas activas (flujo de material) y
        parpadeo de lo que esta en alarma. Muy barato: solo toca items activos."""
        self._fase = (self._fase + 2) % 26
        for l in self.lineas:
            if l["activa"]:
                self.canvas.itemconfig(l["id"], dashoffset=-self._fase)
        self._ciclo += 1
        if self._ciclo % 4 == 0:
            self._blink = not self._blink
            if self._r[mapa.INPUT_REG_ALARMA_CONTADOR]:
                self._pintar_equipos()
                self._pintar_cabeceras()
        self.after(120, self._animar)


class PantallaHMI(tk.Tk):
    def __init__(self, cliente):
        super().__init__()
        self.cliente = cliente
        self.title(f"HMI Planta Completa - Modbus TCP {IP_PLC}:{PUERTO_PLC}")
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{min(1030, sw - 10)}x{min(780, sh - 70)}")
        self.configure(bg=AZUL_PANEL)

        self.filas_dispositivo = {}
        self.filas_silo = {}
        self.filas_bascula = {}
        self.filas_vdf = {}
        self.filas_ingrediente = []
        self._consignas_precargadas = False
        self._tiempos_precargados = False

        self._configurar_estilo()
        self._construir_ui()
        self._activo = True
        threading.Thread(target=self._bucle_sondeo, daemon=True).start()
        self.protocol("WM_DELETE_WINDOW", self._cerrar)

    def _configurar_estilo(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TNotebook", background=AZUL_PANEL, borderwidth=0)
        style.configure("TNotebook.Tab", background=AZUL_PANEL, foreground="white",
                         padding=(6, 3), font=("Sans", 8, "bold"))
        style.map("TNotebook.Tab", background=[("selected", AZUL_FONDO)])
        style.configure("Vertical.TScrollbar", background=AZUL_PANEL)
        style.configure("Formula.Horizontal.TProgressbar", troughcolor=AZUL_PANEL,
                         background=CIAN_BARRA, bordercolor=AZUL_OSCURO)
        style.configure("TCombobox", fieldbackground="white")

    def _construir_ui(self):
        barra_superior = tk.Frame(self, bg=AZUL_PANEL, padx=8, pady=6)
        barra_superior.pack(fill="x")
        tk.Label(barra_superior, text="Estacion HMI - Planta de Alimentos Balanceados",
                  bg=AZUL_PANEL, fg="white", font=("Sans", 12, "bold")).pack(side="left")
        self.lbl_estado_conexion = tk.Label(barra_superior, text="Conectado",
                                             bg=AZUL_PANEL, fg=VERDE_ACTIVO, font=("Sans", 9, "bold"))
        self.lbl_estado_conexion.pack(side="right")
        self.lbl_alarma = tk.Label(barra_superior, text="", bg=AZUL_PANEL, fg="white",
                                    font=("Sans", 9, "bold"), padx=8)
        self.lbl_alarma.pack(side="right", padx=10)

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)
        self.notebook = notebook

        self.pestana_diagrama = PestanaDiagramaGeneral(notebook, self.cliente)
        notebook.add(self.pestana_diagrama, text="Diagrama General")

        for sector in mapa.SECTORES:
            pestana = tk.Frame(notebook, bg=AZUL_FONDO)
            notebook.add(pestana, text=sector.replace("_", " ").title())
            self._construir_pestana_sector(pestana, sector)

        pestana_secuencia = tk.Frame(notebook, bg=AZUL_OSCURO)
        notebook.add(pestana_secuencia, text="Secuencia / Batch")
        self._construir_pestana_secuencia(pestana_secuencia)

    def _construir_pestana_sector(self, contenedor, sector):
        canvas = tk.Canvas(contenedor, bg=AZUL_FONDO, highlightthickness=0)
        scroll = ttk.Scrollbar(contenedor, orient="vertical", command=canvas.yview)
        marco_interno = tk.Frame(canvas, bg=AZUL_FONDO)
        marco_interno.bind("<Configure>",
                            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=marco_interno, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        caja_titulo(marco_interno, f"SECTOR {sector.replace('_', ' ')}", AZUL_FONDO)\
            .pack(anchor="w", padx=6, pady=(8, 6))
        if sector in mapa.SECTOR_ELEVADOR or sector in mapa.SECTOR_VALVULA:
            equipo = mapa.SECTOR_ELEVADOR.get(sector) or mapa.SECTOR_VALVULA.get(sector)
            tk.Label(marco_interno, bg=AZUL_FONDO, fg=AMBAR, justify="left", wraplength=700,
                     font=("Sans", 8),
                     text=f"Para que el material llegue a la bascula deben girar a la vez el rosco "
                          f"del silo y el equipo {equipo} del sector (sensores S en verde).")\
                .pack(anchor="w", padx=8, pady=(0, 4))

        silos_del_sector = [s for s in mapa.SILOS if s["sector"] == sector]
        if silos_del_sector:
            marco_silos = tk.Frame(marco_interno, bg=AZUL_FONDO)
            marco_silos.pack(fill="x", padx=2)
            for silo in silos_del_sector:
                fila = FilaSilo(marco_silos, silo)
                self.filas_silo[silo["nombre"]] = fila

        dispositivos_del_sector = [d for d in mapa.DISPOSITIVOS if d["sector"] == sector]
        if dispositivos_del_sector:
            caja_titulo(marco_interno, "Motores / Valvulas", AZUL_FONDO)\
                .pack(anchor="w", padx=6, pady=(10, 4))
            for disp in dispositivos_del_sector:
                fila = FilaDispositivo(marco_interno, disp, self.cliente)
                self.filas_dispositivo[disp["tag"]] = fila

        basculas_del_sector = [b for b in mapa.BASCULAS
                                if sector.replace("_", " ").lower() in b["nombre"].lower()
                                or (sector == "ACIDO_GRASO" and "acido" in b["nombre"].lower())]
        if basculas_del_sector:
            caja_titulo(marco_interno, "Bascula", AZUL_FONDO).pack(anchor="w", padx=6, pady=(10, 4))
            for bas in basculas_del_sector:
                fila = FilaBascula(marco_interno, bas, self.cliente)
                self.filas_bascula[bas["nombre"]] = fila

        vdfs_del_sector = [v for v in mapa.VDFS
                           if mapa.dispositivo_por_tag(v["motor"])["sector"] == sector]
        if vdfs_del_sector:
            caja_titulo(marco_interno, "Variadores de Frecuencia (VDF)", AZUL_FONDO)\
                .pack(anchor="w", padx=6, pady=(10, 4))
            for vdf in vdfs_del_sector:
                fila = FilaVDF(marco_interno, vdf, self.cliente, bg=AZUL_FONDO)
                self.filas_vdf[vdf["tag"]] = fila

        if sector == "SALIDA":
            caja_titulo(marco_interno, "Silos de Producto Terminado", AZUL_FONDO)\
                .pack(anchor="w", padx=6, pady=(10, 4))
            marco_silos_salida = tk.Frame(marco_interno, bg=AZUL_FONDO)
            marco_silos_salida.pack(fill="x", padx=2)
            for silo_s in mapa.SILOS_SALIDA:
                direccion = mapa.INPUT_REG_DE_SILO_SALIDA[silo_s["nombre"]]
                fila = FilaSilo(marco_silos_salida, silo_s,
                                 capacidad_kg=silo_s["capacidad_kg"], direccion=direccion)
                self.filas_silo[silo_s["nombre"]] = fila

    def _construir_pestana_secuencia(self, contenedor):
        marco = tk.Frame(contenedor, padx=12, pady=10, bg=AZUL_OSCURO)
        marco.pack(fill="both", expand=True)

        caja_titulo(marco, "FORMULA / BATCHS", AZUL_OSCURO).pack(anchor="w", pady=(0, 8))

        fila_control = tk.Frame(marco, bg=AZUL_OSCURO)
        fila_control.pack(fill="x", pady=(0, 8))
        tk.Label(fila_control, text="Formula:", bg=AZUL_OSCURO, fg="white").pack(side="left")
        nombres_formula = [f'{f["id"]} - {f["nombre"]}' for f in mapa.FORMULAS]
        self.combo_formula = ttk.Combobox(fila_control, values=nombres_formula,
                                           state="readonly", width=24)
        self.combo_formula.current(0)
        self.combo_formula.pack(side="left", padx=6)
        self.combo_formula.bind("<<ComboboxSelected>>", self._on_cambio_formula)

        tk.Button(fila_control, text="Iniciar Batch", bg=VERDE_ACTIVO, fg="black",
                   font=("Sans", 9, "bold"),
                   command=self._iniciar_secuencia).pack(side="left", padx=(20, 4))
        tk.Button(fila_control, text="Detener", bg=ROJO_TRIP, fg="white",
                   font=("Sans", 9, "bold"),
                   command=self._detener_secuencia).pack(side="left", padx=4)
        tk.Button(fila_control, text="Reset Alarmas", bg=AMBAR, fg="black",
                   font=("Sans", 9, "bold"),
                   command=self._reset_alarmas).pack(side="left", padx=4)

        fila_estado = tk.Frame(marco, bg=AZUL_OSCURO)
        fila_estado.pack(fill="x", pady=(0, 6))
        self.lbl_estado_secuencia = tk.Label(fila_estado, text="Estado: DETENIDO",
                                              bg=AZUL_OSCURO, fg=AMARILLO, font=("Sans", 11, "bold"))
        self.lbl_estado_secuencia.pack(side="left")
        self.lbl_batch = tk.Label(fila_estado, text="Batchs: 0", width=14,
                                   bg=AZUL_OSCURO, fg="white", font=("Consolas", 10, "bold"))
        self.lbl_batch.pack(side="left", padx=20)
        self.lbl_tiempo_mezclado = tk.Label(fila_estado, text="", bg=AZUL_OSCURO, fg=CIAN_BARRA)
        self.lbl_tiempo_mezclado.pack(side="left")

        # temporizadores de proceso
        fila_tiempos = tk.Frame(marco, bg=AZUL_PANEL, padx=8, pady=4)
        fila_tiempos.pack(fill="x", pady=(0, 6))
        tk.Label(fila_tiempos, text="TIEMPOS", bg=AZUL_PANEL, fg="white",
                 font=("Sans", 8, "bold")).pack(side="left", padx=(0, 10))
        self.lbl_tiempos = tk.Label(fila_tiempos, text="", bg=AZUL_PANEL, fg=CIAN_BARRA,
                                     font=("Consolas", 9, "bold"))
        self.lbl_tiempos.pack(side="left")

        # consignas de tiempo de mezclado / descarga
        fila_sp = tk.Frame(marco, bg=AZUL_OSCURO)
        fila_sp.pack(fill="x", pady=(0, 8))
        tk.Label(fila_sp, text="Tiempo de mezclado (s):", bg=AZUL_OSCURO, fg="white").pack(side="left")
        self.entrada_t_mezclado = tk.Entry(fila_sp, width=5)
        self.entrada_t_mezclado.pack(side="left", padx=4)
        tk.Button(fila_sp, text="Enviar",
                  command=lambda: self._enviar_tiempo(mapa.HOLDING_REG_TIEMPO_MEZCLADO,
                                                      self.entrada_t_mezclado)).pack(side="left")
        tk.Label(fila_sp, text="   Tiempo de descarga (s):", bg=AZUL_OSCURO, fg="white").pack(side="left")
        self.entrada_t_descarga = tk.Entry(fila_sp, width=5)
        self.entrada_t_descarga.pack(side="left", padx=4)
        tk.Button(fila_sp, text="Enviar",
                  command=lambda: self._enviar_tiempo(mapa.HOLDING_REG_TIEMPO_DESCARGA,
                                                      self.entrada_t_descarga)).pack(side="left")

        cabecera = tk.Frame(marco, bg=AZUL_OSCURO)
        cabecera.pack(fill="x", padx=4)
        for texto, ancho, anchor, pad in (("Ingrediente", 17, "w", 0), ("Silo", 15, "w", 0),
                                          ("Objetivo", 9, "e", 0), ("", 18, "w", 0),
                                          ("Entregado", 9, "e", 0), ("Vaciado", 7, "e", 6),
                                          ("Estado", 13, "w", 6)):
            tk.Label(cabecera, text=texto, width=ancho, anchor=anchor, bg=AZUL_OSCURO,
                     fg="#90a4ae", font=("Sans", 8, "bold")).pack(side="left", padx=(pad, 0))

        self.marco_ingredientes = tk.Frame(marco, bg=AZUL_OSCURO)
        self.marco_ingredientes.pack(fill="both", expand=True)
        self._reconstruir_ingredientes(0)

    def _enviar_tiempo(self, direccion, entrada):
        try:
            self.cliente.escribir_registro(direccion, max(1, int(float(entrada.get()))))
        except (ValueError, ConnectionError, OSError):
            pass

    def _reset_alarmas(self):
        try:
            self.cliente.escribir_coil(mapa.COIL_RESET_ALARMAS, True)
        except (ConnectionError, OSError):
            pass

    def _reconstruir_ingredientes(self, idx_formula):
        for w in self.marco_ingredientes.winfo_children():
            w.destroy()
        self.filas_ingrediente = []
        formula = mapa.FORMULAS[idx_formula]
        for ingrediente in formula["ingredientes"]:
            fila = FilaIngrediente(self.marco_ingredientes, ingrediente)
            self.filas_ingrediente.append(fila)

    def _on_cambio_formula(self, event=None):
        idx = self.combo_formula.current()
        self._reconstruir_ingredientes(idx)
        try:
            self.cliente.escribir_registro(mapa.HOLDING_REG_FORMULA_SELECCIONADA, idx)
        except (ConnectionError, OSError):
            pass

    def _iniciar_secuencia(self):
        try:
            self.cliente.escribir_coil(mapa.COIL_SECUENCIA_INICIAR, True)
        except (ConnectionError, OSError):
            pass

    def _detener_secuencia(self):
        try:
            self.cliente.escribir_coil(mapa.COIL_SECUENCIA_DETENER, True)
        except (ConnectionError, OSError):
            pass

    def _bucle_sondeo(self):
        """Polling en bloque: 4 lecturas Modbus cubren TODA la planta."""
        while self._activo:
            try:
                coils = self.cliente.leer_coils(0, mapa.N_COILS)
                discretas = self.cliente.leer_discretas(0, mapa.N_DISCRETAS)
                holding_regs = self.cliente.leer_holding_regs(0, mapa.N_HOLDING_REGS)
                input_regs = self.cliente.leer_input_regs(0, mapa.N_INPUT_REGS)
                self.after(0, self._actualizar_ui, coils, discretas, holding_regs, input_regs)
            except (socket.timeout, ConnectionError, OSError):
                self.after(0, self._marcar_desconectado)
                return
            time.sleep(1)

    def _actualizar_ui(self, coils, discretas, holding_regs, input_regs):
        self.pestana_diagrama.actualizar(coils, discretas, holding_regs, input_regs)

        for tag, fila in self.filas_dispositivo.items():
            direccion = mapa.COIL_DE[tag]
            sensor = atasco = None
            if tag in mapa.DISCRETA_SENSOR_DE:
                sensor = discretas[mapa.DISCRETA_SENSOR_DE[tag]]
                atasco = coils[mapa.COIL_ATASCO_DE[tag]]
            fila.actualizar(coils[direccion], discretas[direccion], sensor,
                            bool(discretas[mapa.DISCRETA_ALARMA_DISP_DE[tag]]), atasco)

        for nombre, fila in self.filas_silo.items():
            fila.actualizar(input_regs[fila.direccion])

        for nombre, fila in self.filas_bascula.items():
            direccion = mapa.INPUT_REG_DE_BASCULA[nombre]
            fila.actualizar(input_regs[direccion])

        for tag, fila in self.filas_vdf.items():
            frecuencia = input_regs[mapa.INPUT_REG_DE_VDF_FRECUENCIA[tag]]
            estado_bits = input_regs[mapa.INPUT_REG_DE_VDF_ESTADO[tag]]
            fila.actualizar(frecuencia, estado_bits)
            if not self._consignas_precargadas:
                consigna = holding_regs[mapa.HOLDING_REG_DE_VDF_CONSIGNA[tag]]
                fila.entrada_consigna.insert(0, f"{consigna / 10.0:.1f}")
        self._consignas_precargadas = True

        if not self._tiempos_precargados:
            self.entrada_t_mezclado.insert(0, str(holding_regs[mapa.HOLDING_REG_TIEMPO_MEZCLADO]))
            self.entrada_t_descarga.insert(0, str(holding_regs[mapa.HOLDING_REG_TIEMPO_DESCARGA]))
            self._tiempos_precargados = True

        activas = input_regs[mapa.INPUT_REG_ALARMA_CONTADOR]
        if activas:
            self.lbl_alarma.config(text=f"ALARMAS ACTIVAS: {activas}", bg=ROJO_TRIP)
        else:
            self.lbl_alarma.config(text="", bg=AZUL_PANEL)

        self._actualizar_secuencia(input_regs)

    def _actualizar_secuencia(self, input_regs):
        r = input_regs
        estado = r[mapa.INPUT_REG_ESTADO_SECUENCIA]
        batch = r[mapa.INPUT_REG_BATCH_ACTUAL]
        formula_idx = r[mapa.INPUT_REG_FORMULA_ACTUAL]
        ingrediente_idx = r[mapa.INPUT_REG_INGREDIENTE_IDX]
        avance = r[mapa.INPUT_REG_AVANCE_INGREDIENTE] / 10.0
        tiempo_mezclado = r[mapa.INPUT_REG_TIEMPO_MEZCLADO]

        self.lbl_estado_secuencia.config(text=f"Estado: {mapa.ESTADOS_SECUENCIA[estado]}",
                                         fg=ROJO_TRIP if estado == 4 else AMARILLO)
        self.lbl_batch.config(text=f"Batchs: {batch}")
        self.lbl_tiempo_mezclado.config(
            text=f"Mezclando... {tiempo_mezclado}s restantes" if estado == 2 else "")
        self.lbl_tiempos.config(
            text=(f"Total {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_BATCH_TOTAL])}   "
                  f"Dosif {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_DOSIFICACION])}   "
                  f"Mezcla {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_MEZCLA])}   "
                  f"Descarga {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_DESCARGA])}   "
                  f"Ultimo batch {fmt_mmss(r[mapa.INPUT_REG_TIEMPO_ULTIMO_BATCH])}"))

        if self.combo_formula.current() != formula_idx:
            self.combo_formula.current(formula_idx)
            self._reconstruir_ingredientes(formula_idx)

        activo = ingrediente_idx if ingrediente_idx != 0xFFFF else -1
        for i, fila in enumerate(self.filas_ingrediente):
            ing = fila.ingrediente
            entregado = r[mapa.INPUT_REG_KG_SILO_BATCH[ing["silo"]]] / 10.0
            tiempo = r[mapa.INPUT_REG_TIEMPO_SILO[ing["silo"]]]
            if estado == 1 and i == activo:
                fila.actualizar("dosificando...", avance, entregado, tiempo)
            elif estado == 4 and i == activo:
                fila.actualizar("ALARMA", None, entregado, tiempo)
            elif entregado >= ing["objetivo_kg"] - 0.05:
                fila.actualizar("completado", None, entregado, tiempo)
            else:
                fila.actualizar("pendiente", None, entregado, tiempo)

    def _marcar_desconectado(self):
        self.lbl_estado_conexion.config(text="Desconectado del PLC", fg=ROJO_TRIP)

    def _cerrar(self):
        self._activo = False
        self.destroy()


def main():
    cliente = ClienteModbus(IP_PLC, PUERTO_PLC)
    app = PantallaHMI(cliente)
    app.mainloop()


if __name__ == "__main__":
    main()
